//
//  MovieGridCell.swift
//  flixter
//
//  Created by Travis Blalack on 9/15/21.
//

import UIKit
import AlamofireImage

class MovieGridCell: UICollectionViewCell {
    @IBOutlet weak var posterView: UIImageView!
    
}
